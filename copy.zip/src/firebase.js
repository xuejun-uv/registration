// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { doc, setDoc } from "firebase/firestore";
import { db } from "../firebase";

const saveUserStamps = async (userId, stamps) => {
  await setDoc(doc(db, "users", userId), { stamps });
};

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDiPpHzA_EB2HctYykz3bJLS40-lkuhJdg",
  authDomain: "add-a-web-app-fcd6c.firebaseapp.com",
  projectId: "add-a-web-app-fcd6c",
  storageBucket: "add-a-web-app-fcd6c.firebasestorage.app",
  messagingSenderId: "1038860701851",
  appId: "1:1038860701851:web:f8c1b71789aee83d58f63e",
  measurementId: "G-4CSGKYLW3H"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);