import React from "react";
import { useNavigate } from "react-router-dom";
import "../index.css";

const HomePage = () => {
  const navigate = useNavigate();

  const goToStampPage = () => {
    navigate("/stamps");
  };

  return (
    <div
      style={{
        textAlign: "center",
        height: "100vh",
        overflow: "hidden", // non-scrollable
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <h1>School of Technology</h1>
      <button
        onClick={() => window.open("https://formsg.link", "_blank")}
        style={{ margin: "10px", padding: "10px 20px" }}
      >
        Link to FormSG
      </button>
      <button
        onClick={goToStampPage}
        style={{ margin: "10px", padding: "10px 20px" }}
      >
        Proceed
      </button>
    </div>
  );
};

export default HomePage;
