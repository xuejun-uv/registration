import React, { useState } from "react";
import QrScanner from "qr-scanner";
import StampGrid from "../components/StampGrid";

const StampPage = () => {
  const [stamps, setStamps] = useState([]);

  const handleScan = async () => {
    const videoElem = document.createElement("video");
    const qrScanner = new QrScanner(videoElem, (result) => {
      const qrCode = result.data;
      if (!stamps.includes(qrCode)) {
        setStamps([...stamps, qrCode]);
      }
      qrScanner.stop();
    });
    await qrScanner.start();
    document.body.appendChild(videoElem);
  };

  return (
    <div style={{ padding: "20px" }}>
      <button onClick={handleScan}>📷 Open Camera</button>

      <h2>Discovery Atrium</h2>
      <StampGrid count={4} stamps={stamps.slice(0, 4)} />

      <h2>Envision Gallery</h2>
      <StampGrid count={3} stamps={stamps.slice(4, 7)} />

      <h2>Experience Zone</h2>
      <StampGrid count={4} stamps={stamps.slice(7, 11)} />
    </div>
  );
};

export default StampPage;
