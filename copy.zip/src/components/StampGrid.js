import React from "react";

const StampGrid = ({ count, stamps }) => {
  const boxes = Array.from({ length: count });
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(2, 100px)",
        gap: "10px",
        marginBottom: "20px",
      }}
    >
      {boxes.map((_, i) => (
        <div
          key={i}
          style={{
            width: "100px",
            height: "100px",
            border: "2px solid gray",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: stamps[i] ? "#d4edda" : "#f8f9fa",
          }}
        >
          {stamps[i] ? "✅" : ""}
        </div>
      ))}
    </div>
  );
};

export default StampGrid;
